export default async function handler(req,res){
  if(req.method!=="POST") return res.status(405).json({error:"Method not allowed"});
  try{
    const {idea,location,budget}=req.body||{};
    if(!idea) return res.status(400).json({error:"Décris ton projet."});
    const prompt=`Tu es l'analyste du site "Est-ce rentable ?".
Projet utilisateur : ${idea}
Zone : ${location||"non précisée"}
Budget : ${budget||"non précisé"}

Analyse l'opportunité d'investissement. Tu dois rechercher des informations actuelles sur le Web avant de donner des prix ou tarifs. Compare plusieurs sources. Ne jamais inventer un prix. Si une donnée est incertaine, indique-le.
Cherche aussi des alternatives à l'idée initiale si elles semblent plus rentables.
Réponds en français, avec :
1) verdict (vert/orange/rouge/incertain)
2) résumé
3) 3 à 5 opportunités
4) pour chacune : prix d'achat, fourchette, tarif de location, nombre de locations/an prudent, CA, coûts, bénéfice, ROI, amortissement, confiance et explication
5) meilleure option
6) prix maximum d'achat conseillé
7) avertissements.

Important : les calculs doivent être cohérents et conservateurs.`;

    const r=await fetch("https://api.openai.com/v1/responses",{
      method:"POST",
      headers:{"Content-Type":"application/json","Authorization":`Bearer ${process.env.OPENAI_API_KEY}`},
      body:JSON.stringify({
        model:"gpt-5.4-mini",
        tools:[{type:"web_search"}],
        input:prompt
      })
    });
    const data=await r.json();
    if(!r.ok) return res.status(r.status).json({error:data.error?.message||"Erreur OpenAI"});
    const text=data.output_text||data.output?.map(x=>x.content?.map(c=>c.text||"").join("")).join("")||"";
    return res.json({text});
  }catch(e){return res.status(500).json({error:e.message||"Erreur serveur"})}
}